---
title: "Agent Coord Local"
type: code
sub_layer: structural
content_trust_score: 0.7
created: "2026-09-13"
updated: "2026-09-13"
tags: [script, wiki-a]
related: []
status: generated
source_file: "scripts/global/agent-coord-local.js"
source_path: "scripts/global/agent-coord-local.js"
source_sha256: 9993ecda3c7ebc5907cb4b156c151966941ef6e9bcf1d54cf976bafe49c204fa
last_updated: "2026-09-13"
generated_by_run: reconcile
---

# Agent Coord Local

> **Source**: `scripts/global/agent-coord-local.js` | **Type**: script | **Trust**: 0.7

## Invisible Character Scan

  none
