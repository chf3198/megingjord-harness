---
title: "Actuator Engine"
type: code
sub_layer: structural
content_trust_score: 0.7
created: "2026-09-13"
updated: "2026-09-13"
tags: [script, wiki-a]
related: []
status: generated
source_file: "scripts/global/actuator-engine.js"
source_path: "scripts/global/actuator-engine.js"
source_sha256: 23751a8141abb2181e17b071968642ac515ba0c5cd64701f65d68871f1a1e5c3
last_updated: "2026-09-13"
generated_by_run: reconcile
---

# Actuator Engine

> **Source**: `scripts/global/actuator-engine.js` | **Type**: script | **Trust**: 0.7

## Invisible Character Scan

  none
